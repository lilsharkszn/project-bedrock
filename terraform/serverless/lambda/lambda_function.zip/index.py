def lambda_handler(event, context):
    for record in event.get('Records', []):
        bucket = record.get('s3', {}).get('bucket', {}).get('name')
        key = record.get('s3', {}).get('object', {}).get('key')
        print(f"Image received: {key} from bucket {bucket}")
    return {"statusCode": 200, "body": "Logged successfully"}
